Para realizar la animación de la cola debemos pulsar la letra "C".
Para realizar la animación de las pinzas debemos pulsar la letra "P".
La animación de las piernas es automatica.
No se ha incluido modificación interactiva de las velocidades.
