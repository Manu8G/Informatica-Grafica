Los botones añadidos son el 
	1-Luz ambiental y difusa, desactiva la especular
	2-Luz ambiental y especular, desactiva la difusa
	3-Desactiva las dos anteriores
